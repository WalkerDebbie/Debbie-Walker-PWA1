var access = document.getElementById("code9");
var code = access.innerHTML; 
code = code + " midnight"; 
alert(code);
