<!-- Tufts VUE 3.2.2 concept-map (Day3DuelFlowchart_Walker_Debbie.vue) 2015-01-25 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/Applications/VUE.app/Contents/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Sun Jan 25 21:12:59 EST 2015 by debbiewalker on platform Mac OS X 10.9.5 in JVM 1.6.0_65-b14-462-11M4609 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 23 2013 at 2146 by tomadm on Linux 2.6.18-348.2.1.el5 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="Day3DuelFlowchart_Walker_Debbie.vue" created="1421011985533"
    x="0.0" y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1422238379240"
        spec="/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/Apps/goal4_assign_duel3/flowchart/Day3DuelFlowchart_Walker_Debbie.vue"
        type="1" xsi:type="URLResource">
        <title>Day3DuelFlowchart_Walker_Debbie.vue</title>
        <property key="File" value="/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/Apps/goal4_assign_duel3/flowchart/Day3DuelFlowchart_Walker_Debbie.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/db743cfbc0a800070093c5e75c6c48e9</URIString>
    <child ID="6" label="START" layerID="1" created="1421012572739"
        x="11.250061" y="-57.166656" width="149.0" height="49.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfcc0a800070093c5e70ac927a3</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="7" label="MAIN&#xa;(self-executing)&#xa;function()"
        layerID="1" created="1421012604310" x="0.25006104" y="50.500114"
        width="167.0" height="90.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfcc0a800070093c5e7bd0df089</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="8" label="console.log&#xa;&quot;FIGHT!!!&quot;"
        layerID="1" created="1421012669074" x="-10.999939" y="182.6703"
        width="189.0" height="78.16304" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfcc0a800070093c5e78510ebdc</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="9" label="&quot;Program Starts&quot;" layerID="1"
        created="1421012696754" x="186.50006" y="181.83334"
        width="170.07762" height="81.8" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfdc0a800070093c5e7d9e95c17</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="13" label="Define Global&#xa;Variables" layerID="1"
        created="1421013083151" x="401.86407" y="182.5"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfdc0a800070093c5e72dbfee4c</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="14" label="Run fight()&#xa;function" layerID="1"
        created="1421013115270" x="580.88824" y="183.5"
        width="158.11176" height="80.62895" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfec0a800070093c5e79dec9c63</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="17"
        label="User Clicks&#xa;&quot;OK&quot; Button&#xa;(alert box)"
        layerID="1" created="1421013211305" x="532.75" y="428.0"
        width="187.0" height="96.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfec0a800070093c5e7c2d7f64d</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="18"
        label="&quot;START&quot;&#xa;Player Health.&#xa;Damage, Round"
        layerID="1" created="1421013357337" x="554.9166" y="295.41663"
        width="194.66669" height="101.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cffc0a800070093c5e794dec85f</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="19"
        label="Global Variables&#xa;//player name&#xa;    var playerOneName = &quot;Red Robot&quot;; //  declare a variable for player 1 to be the value of &quot;Red Robot&quot;&#xa;    var playerTwoName = &quot;Blue Robot&quot;;  // declare a variable for player 2 to be the value of &quot;Blue Robot&quot;&#xa;&#xa;    //player damage&#xa;    var player1Damage = 20; //  declare a variable player 1 damage to be the value of 20&#xa;    var player2Damage = 20; // declare a variable player 2 damage to be the value of 20&#xa;&#xa;    //player health&#xa;    var playerOneHealth = 100; // declare  a variable player 1 health to be the value 100&#xa;    var playerTwoHealth = 100; // declare a variable player 2 health to be the value 100&#xa;&#xa;    var round=0; "
        layerID="1" created="1421013792580" x="265.16663" y="-122.16667"
        width="591.0" height="222.33334" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#D0D0D0</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cffc0a800070093c5e70be63332</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="20"
        label="Debbie Walker | January 2015 | Goal4: Assignment: Duel 3"
        layerID="1" created="1421013940063" x="-294.99997"
        y="-185.66647" width="434.0" height="23.0" strokeWidth="0.0"
        autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cffc0a800070093c5e747c5ba07</URIString>
        <richText>&lt;html&gt;
  &lt;head color="#000000" style="color: #000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { margin-top: 0px; font-size: 12; margin-bottom: 0px; font-family: Arial; margin-right: 0px; margin-left: 0px; color: #000000 }
        ol { margin-top: 6; font-size: 12; vertical-align: middle; font-family: Arial; margin-left: 30; list-style-position: outside }
        p { margin-top: 0; margin-bottom: 0; margin-right: 0; margin-left: 0; color: #000000 }
        ul { margin-top: 6; font-size: 12; vertical-align: middle; font-family: Arial; margin-left: 30; list-style-position: outside }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p color="#000000" style="color: #000000"&gt;
      Debbie Walker | January 2015 | Goal4: Assignment: Duel 3
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Debbie Walker | January 2015 | Goal4: Assignment: Duel 3</label>
    </child>
    <child ID="26" layerID="1" created="1421014333057" x="83.95227"
        y="-8.679199" width="1.9156723" height="59.6792"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d00c0a800070093c5e7d92a2785</URIString>
        <point1 x="85.36795" y="-8.179199"/>
        <point2 x="84.45228" y="50.5"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="28" layerID="1" created="1421014397426" x="83.07745"
        y="140.0" width="1.0835037" height="43.171875" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d01c0a800070093c5e7732d0d32</URIString>
        <point1 x="83.66095" y="140.5"/>
        <point2 x="83.577446" y="182.67188"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">8</ID2>
    </child>
    <child ID="29" layerID="1" created="1421014403074" x="158.40973"
        y="221.64545" width="28.590347" height="1.1440125"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d01c0a800070093c5e7508956bd</URIString>
        <point1 x="158.90971" y="222.14545"/>
        <point2 x="186.50006" y="222.28946"/>
        <ID1 xsi:type="node">8</ID1>
        <ID2 xsi:type="node">9</ID2>
    </child>
    <child ID="30" layerID="1" created="1421014430968" x="356.0777"
        y="222.34566" width="46.286377" height="1.0598145"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d02c0a800070093c5e7186775f8</URIString>
        <point1 x="356.5777" y="222.84566"/>
        <point2 x="401.86407" y="222.90547"/>
        <ID1 xsi:type="node">9</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="31" layerID="1" created="1421014440672" x="544.5"
        y="222.81253" width="36.888245" height="1.156723"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d06c0a800070093c5e78ea06894</URIString>
        <point1 x="545.0" y="223.31253"/>
        <point2 x="580.88824" y="223.46925"/>
        <ID1 xsi:type="node">13</ID1>
        <ID2 xsi:type="node">14</ID2>
    </child>
    <child ID="39" label="&quot;Players Names &amp; Health&quot;"
        layerID="1" created="1421015160625" x="1038.5" y="551.3335"
        width="203.6" height="96.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d06c0a800070093c5e75a73d35a</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="40" label="console.log&#xa;&quot;Results&quot;"
        layerID="1" created="1421015205588" x="719.0667" y="429.33353"
        width="154.5" height="93.49997" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d07c0a800070093c5e769a68c5d</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="42" label="Rounds&#xa;&lt; 10; &#xa;No&#xa;Winner?"
        layerID="1" created="1421015319833" x="825.44525" y="526.3541"
        width="157.66669" height="145.99976" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d07c0a800070093c5e71780d582</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="43" label="TRUE" layerID="1" created="1421015319833"
        x="780.3534" y="522.3335" width="82.18323" height="134.18024"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d07c0a800070093c5e7998f5a40</URIString>
        <point1 x="862.0366" y="633.2377"/>
        <point2 x="790.0286" y="522.8335"/>
        <ID1 xsi:type="node">42</ID1>
        <ID2 xsi:type="node">40</ID2>
        <ctrlPoint0 x="764.6742" y="711.3356" xsi:type="point"/>
    </child>
    <child ID="44" layerID="1" created="1421015459232" x="863.53503"
        y="453.21625" width="68.231445" height="90.09039"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d08c0a800070093c5e72d2f564e</URIString>
        <point1 x="864.03503" y="458.17538"/>
        <point2 x="922.0456" y="542.80664"/>
        <ID1 xsi:type="node">40</ID1>
        <ID2 xsi:type="node">42</ID2>
        <ctrlPoint0 x="956.30304" y="433.77512" xsi:type="point"/>
    </child>
    <child ID="50" label="FALSE" layerID="1" created="1421015517461"
        x="967.6755" y="572.80835" width="98.390076" height="13.214478"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d08c0a800070093c5e70edf9a4c</URIString>
        <point1 x="968.1755" y="585.5228"/>
        <point2 x="1065.5656" y="583.52466"/>
        <ID1 xsi:type="node">42</ID1>
        <ID2 xsi:type="node">39</ID2>
        <ctrlPoint0 x="1020.9786" y="574.093" xsi:type="point"/>
    </child>
    <child ID="53" label="result&#xa;no winner" layerID="1"
        created="1421015937606" x="1465.7499" y="904.54" width="203.6"
        height="96.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d09c0a800070093c5e75679391e</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="54" label="&quot;Player's Name &amp; Health&quot;"
        layerID="1" created="1421015937606" x="1127.4999" y="785.62335"
        width="199.0" height="94.99997" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d09c0a800070093c5e739c960ef</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="55"
        label="are resuts&#xa;absolutly&#xa;&quot;No Winner&quot;?"
        layerID="1" created="1421015937606" x="1249.4452" y="880.644"
        width="157.66669" height="145.99976" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d09c0a800070093c5e75dfb01db</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="56" label="TRUE" layerID="1" created="1421015937606"
        x="1164.1687" y="880.1233" width="99.941284" height="92.51007"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0ac0a800070093c5e7553333da</URIString>
        <point1 x="1263.61" y="966.7605"/>
        <point2 x="1197.7317" y="880.6233"/>
        <ID1 xsi:type="node">55</ID1>
        <ID2 xsi:type="node">54</ID2>
        <ctrlPoint0 x="1127.6666" y="994.3335" xsi:type="point"/>
    </child>
    <child ID="58" label="FALSE" layerID="1" created="1421015937606"
        x="1391.6753" y="927.0765" width="101.21741" height="13.236206"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0ac0a800070093c5e78cd39f06</URIString>
        <point1 x="1392.1753" y="939.8127"/>
        <point2 x="1492.3927" y="937.7275"/>
        <ID1 xsi:type="node">55</ID1>
        <ID2 xsi:type="node">53</ID2>
        <ctrlPoint0 x="1444.9785" y="928.3828" xsi:type="point"/>
    </child>
    <child ID="60" label="console.log&#xa;results of the round"
        layerID="1" created="1421016648461" x="1022.0" y="673.3335"
        width="201.0" height="93.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0ac0a800070093c5e7e7c59cf8</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="62" label="console.log&#xa;&quot;no winner&quot;"
        layerID="1" created="1421017837812" x="1440.8334" y="1038.8339"
        width="200.41663" height="87.74988" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0bc0a800070093c5e7f1e3c043</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="64" label="return (Player Name)&#xa;&quot;WINS!!!!&quot;"
        layerID="1" created="1421018157149" x="1819.6167" y="1274.4899"
        width="203.6" height="96.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0bc0a800070093c5e7d593f658</URIString>
        <shape xsi:type="rhombus"/>
    </child>
    <child ID="65"
        label="result&#xa;&quot;Player's Name &amp; Health&quot;"
        layerID="1" created="1421018157149" x="1484.6167" y="1154.4899"
        width="199.0" height="94.99997" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0bc0a800070093c5e76318e192</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="66"
        label="if both Players&#xa;are &lt;1&#xa;result is&#xa;&quot;You Both Die&quot;"
        layerID="1" created="1421018157149" x="1606.562" y="1249.5105"
        width="158.4" height="145.99976" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0cc0a800070093c5e7b26f6f3b</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="67" label="TRUE" layerID="1" created="1421018157149"
        x="1536.4495" y="1248.9897" width="107.41394" height="137.96863"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0cc0a800070093c5e7a7cce249</URIString>
        <point1 x="1643.3634" y="1356.4305"/>
        <point2 x="1563.9597" y="1249.4897"/>
        <ID1 xsi:type="node">66</ID1>
        <ID2 xsi:type="node">65</ID2>
        <ctrlPoint0 x="1545.791" y="1434.492" xsi:type="point"/>
        <ctrlPoint1 x="1522.2998" y="1347.6602" xsi:type="point"/>
    </child>
    <child ID="68" layerID="1" created="1421018157149" x="1683.1167"
        y="1170.3777" width="62.587036" height="114.34082"
        strokeWidth="1.0" autoSized="false" controlCount="2"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0cc0a800070093c5e7fd80b238</URIString>
        <point1 x="1683.6167" y="1172.7451"/>
        <point2 x="1723.418" y="1284.2185"/>
        <ID1 xsi:type="node">65</ID1>
        <ID2 xsi:type="node">66</ID2>
        <ctrlPoint0 x="1737.4197" y="1156.9314" xsi:type="point"/>
        <ctrlPoint1 x="1769.3679" y="1237.4923" xsi:type="point"/>
    </child>
    <child ID="69" label="FALSE" layerID="1" created="1421018157149"
        x="1764.4546" y="1316.0002" width="76.01904" height="13.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0dc0a800070093c5e78b0460e9</URIString>
        <point1 x="1764.9546" y="1322.5035"/>
        <point2 x="1839.9736" y="1322.497"/>
        <ID1 xsi:type="node">66</ID1>
        <ID2 xsi:type="node">64</ID2>
    </child>
    <child ID="71" label="END" layerID="1" created="1421019550586"
        x="1838.4166" y="1423.4169" width="140.8333" height="63.916626"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0dc0a800070093c5e7ccf697fe</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="73" layerID="1" created="1421019626665" x="654.9321"
        y="263.6289" width="2.9716187" height="32.288086"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0dc0a800070093c5e75f5bb493</URIString>
        <point1 x="657.40375" y="264.1289"/>
        <point2 x="655.4321" y="295.417"/>
        <ID1 xsi:type="node">14</ID1>
        <ID2 xsi:type="node">18</ID2>
    </child>
    <child ID="74" layerID="1" created="1421019632297" x="645.16675"
        y="395.91687" width="2.083313" height="31.333344"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0ec0a800070093c5e71382635c</URIString>
        <point1 x="646.75" y="396.41687"/>
        <point2 x="645.6667" y="426.7502"/>
    </child>
    <child ID="75" layerID="1" created="1421019643769" x="702.5937"
        y="470.25403" width="33.814636" height="2.1185913"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0ec0a800070093c5e7e72e474a</URIString>
        <point1 x="703.0937" y="470.75403"/>
        <point2 x="735.9083" y="471.87262"/>
        <ID1 xsi:type="node">17</ID1>
        <ID2 xsi:type="node">40</ID2>
        <ctrlPoint0 x="711.56506" y="470.17572" xsi:type="point"/>
    </child>
    <child ID="76" layerID="1" created="1421019773202" x="1122.0938"
        y="646.8335" width="4.4976807" height="26.979004"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d0fc0a800070093c5e7dd9deb73</URIString>
        <point1 x="1126.0914" y="647.3335"/>
        <point2 x="1122.5938" y="673.3125"/>
        <ID1 xsi:type="node">39</ID1>
        <ID2 xsi:type="node">60</ID2>
        <ctrlPoint0 x="1122.6224" y="659.05304" xsi:type="point"/>
    </child>
    <child ID="77" layerID="1" created="1421019790825" x="1107.6647"
        y="765.8335" width="37.9187" height="70.91675" strokeWidth="1.0"
        autoSized="false" controlCount="1" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d10c0a800070093c5e7f6d74305</URIString>
        <point1 x="1111.9502" y="766.3335"/>
        <point2 x="1145.0834" y="836.25024"/>
        <ID1 xsi:type="node">60</ID1>
        <ctrlPoint0 x="1096.3334" y="835.1669" xsi:type="point"/>
    </child>
    <child ID="78" layerID="1" created="1421019825871" x="1540.5881"
        y="1000.04004" width="7.8009033" height="39.33496"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d10c0a800070093c5e7e11da04a</URIString>
        <point1 x="1547.889" y="1000.54004"/>
        <point2 x="1541.0881" y="1038.875"/>
        <ID1 xsi:type="node">53</ID1>
        <ID2 xsi:type="node">62</ID2>
        <ctrlPoint0 x="1541.1112" y="1017.08746" xsi:type="point"/>
    </child>
    <child ID="79" layerID="1" created="1421019836599" x="1453.0977"
        y="1126.0837" width="36.67627" height="66.140625"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d10c0a800070093c5e7f0abf41a</URIString>
        <point1 x="1489.2739" y="1126.5837"/>
        <point2 x="1484.6167" y="1191.7244"/>
        <ID1 xsi:type="node">62</ID1>
        <ID2 xsi:type="node">65</ID2>
        <ctrlPoint0 x="1420.25" y="1185.0835" xsi:type="point"/>
    </child>
    <child ID="80" layerID="1" created="1421019858454" x="1905.0833"
        y="1372.0" width="2.9989014" height="51.972534"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d11c0a800070093c5e7d8a4a57f</URIString>
        <point1 x="1905.5834" y="1372.5001"/>
        <point2 x="1907.5823" y="1423.4727"/>
        <ID2 xsi:type="node">71</ID2>
    </child>
    <child ID="82" layerID="1" created="1421020270697" x="1325.9999"
        y="824.0343" width="54.843872" height="96.13251"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d11c0a800070093c5e795996e0d</URIString>
        <point1 x="1326.4999" y="824.5343"/>
        <point2 x="1374.3334" y="919.6668"/>
        <ID1 xsi:type="node">54</ID1>
        <ctrlPoint0 x="1398.3334" y="818.3335" xsi:type="point"/>
    </child>
    <child ID="83" label="js" layerID="1" created="1421020330943"
        x="-167.0" y="-76.33313" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d11c0a800070093c5e71f8367cc</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="85" label="css" layerID="1" created="1421020361446"
        x="-165.5" y="21.666874" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FDE888</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e76a1df893</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="86" label="images" layerID="1" created="1421020370053"
        x="-162.83334" y="125.66687" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#DD7B11</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e7f64ddae6</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="90" label="HTML" layerID="1" created="1421020675678"
        x="-322.11713" y="23.13536" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e77ff7bb8d</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="91" layerID="1" created="1421020701879" x="-266.0021"
        y="-38.263298" width="98.46835" height="61.89867"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e718c445bf</URIString>
        <point1 x="-265.5021" y="23.135376"/>
        <point2 x="-168.03375" y="-37.763298"/>
        <ID1 xsi:type="node">90</ID1>
        <ctrlPoint0 x="-234.03085" y="-30.941307" xsi:type="point"/>
    </child>
    <child ID="92" layerID="1" created="1421020719826" x="-269.9432"
        y="98.635376" width="107.60986" height="61.588455"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d13c0a800070093c5e77c47c549</URIString>
        <point1 x="-269.4432" y="99.135376"/>
        <point2 x="-162.83334" y="159.72383"/>
        <ID1 xsi:type="node">90</ID1>
        <ID2 xsi:type="node">86</ID2>
        <ctrlPoint0 x="-244.95494" y="150.33806" xsi:type="point"/>
    </child>
    <child ID="93" layerID="1" created="1421020746873" x="-253.61713"
        y="59.490356" width="88.61713" height="1.8215218"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d13c0a800070093c5e7fca13444</URIString>
        <point1 x="-253.11713" y="60.81188"/>
        <point2 x="-165.5" y="59.990356"/>
        <ID1 xsi:type="node">90</ID1>
        <ID2 xsi:type="node">85</ID2>
    </child>
    <child ID="94" label="Player 2&#xa;Red Robot" layerID="1"
        created="1421020793479" x="-431.1171" y="66.95293"
        width="85.09999" height="53.650906" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#EA2218</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d13c0a800070093c5e7286a1ee5</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="95" label="Player 1&#xa;Blue Robot" layerID="1"
        created="1421020807438" x="-431.9333" y="-3.827488"
        width="87.700005" height="53.650906" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#0877C0</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d14c0a800070093c5e7b2a00948</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <layer ID="1" label="Layer 1" created="1421011985533" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/db743d14c0a800070093c5e71a7e0ef3</URIString>
    </layer>
    <userZoom>2.0</userZoom>
    <userOrigin x="-882.8666" y="-389.33295"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1421011985533"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="0" open="true">
            <strokeColor>#B3CC33CC</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/db743d14c0a800070093c5e7a58ac94e</URIString>
            <masterSlide ID="2" created="1421011985644" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e7c9c38b08</URIString>
                <titleStyle ID="3" label="Header"
                    created="1421011985651" x="341.0" y="175.0"
                    width="118.0" height="50.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e79b62f077</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1421011985651" x="349.5" y="282.5"
                    width="101.0" height="35.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e78058b35e</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1421011985652"
                    x="375.5" y="385.0" width="49.0" height="30.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e70b272010</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2015-01-11</date>
    <modelVersion>6</modelVersion>
    <saveLocation>/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/Apps/goal4_assign_duel3/flowchart</saveLocation>
    <saveFile>/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/Apps/goal4_assign_duel3/flowchart/Day3DuelFlowchart_Walker_Debbie.vue</saveFile>
</LW-MAP>
