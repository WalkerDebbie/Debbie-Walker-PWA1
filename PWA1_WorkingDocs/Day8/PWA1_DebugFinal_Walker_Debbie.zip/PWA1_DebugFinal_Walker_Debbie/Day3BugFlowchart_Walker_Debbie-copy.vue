<!-- Tufts VUE 3.2.2 concept-map (Day3BugFlowchart_Walker_Debbie-copy.vue) 2015-01-25 -->
<!-- Tufts VUE: http://vue.tufts.edu/ -->
<!-- Do Not Remove: VUE mapping @version(1.1) jar:file:/Applications/VUE.app/Contents/VUE.jar!/tufts/vue/resources/lw_mapping_1_1.xml -->
<!-- Do Not Remove: Saved date Sun Jan 25 22:38:29 EST 2015 by debbiewalker on platform Mac OS X 10.9.5 in JVM 1.6.0_65-b14-462-11M4609 -->
<!-- Do Not Remove: Saving version @(#)VUE: built May 23 2013 at 2146 by tomadm on Linux 2.6.18-348.2.1.el5 i386 JVM 1.7.0_21-b11(bits=32) -->
<?xml version="1.0" encoding="US-ASCII"?>
<LW-MAP xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xsi:noNamespaceSchemaLocation="none" ID="0"
    label="Day3BugFlowchart_Walker_Debbie-copy.vue"
    created="1421011985533" x="0.0" y="0.0" width="1.4E-45"
    height="1.4E-45" strokeWidth="0.0" autoSized="false">
    <resource referenceCreated="1422243509867"
        spec="/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/PWA1_WorkingDocs/Day9/Day3BugFlowchart_Walker_Debbie-copy.vue"
        type="1" xsi:type="URLResource">
        <title>Day3BugFlowchart_Walker_Debbie-copy.vue</title>
        <property key="File" value="/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/PWA1_WorkingDocs/Day9/Day3BugFlowchart_Walker_Debbie-copy.vue"/>
    </resource>
    <fillColor>#FFFFFF</fillColor>
    <strokeColor>#404040</strokeColor>
    <textColor>#000000</textColor>
    <font>SansSerif-plain-14</font>
    <URIString>http://vue.tufts.edu/rdf/resource/db743cfbc0a800070093c5e75c6c48e9</URIString>
    <child ID="6" label="START" layerID="1" created="1421012572739"
        x="-252.74994" y="-341.16663" width="149.0" height="49.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#DD7B11</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfcc0a800070093c5e70ac927a3</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="7" label="MAIN&#xa;(self-executing)&#xa;function()"
        layerID="1" created="1421012604310" x="-263.74994"
        y="-233.49985" width="167.0" height="90.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfcc0a800070093c5e7bd0df089</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="13" label="Define Global&#xa;Variables" layerID="1"
        created="1421013083151" x="-252.13593" y="-95.49997"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cfdc0a800070093c5e72dbfee4c</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="19"
        label="&#x9;Global Variables&#xa;var resultsDIV = document.getElementById(&quot;results&quot;); &#xa;&#x9;var validate = function(query){ &#xa;&#x9;var search = function(query) {&#x9;&#xa;&#x9;var showMatches = function(results){&#x9;&#xa;&#x9;var html = '&lt;p>Results&lt;/p>', &#x9;&#x9;&#x9;&#xa;&#x9;&#x9;title, &#x9;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;&#xa;&#x9;&#x9;url;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;&#x9;"
        layerID="1" created="1421013792580" x="-21.833374"
        y="-350.66663" width="335.3335" height="162.33354"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#D0D0D0</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cffc0a800070093c5e70be63332</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="20"
        label="Debbie Walker | January 2015 | Goal 1: Assignment: Debug V3"
        layerID="1" created="1421013940063" x="-675.0" y="-437.6664"
        width="432.0" height="20.0" strokeWidth="0.0" autoSized="false" xsi:type="text">
        <strokeColor>#404040</strokeColor>
        <textColor>#000000</textColor>
        <font>SansSerif-plain-14</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743cffc0a800070093c5e747c5ba07</URIString>
        <richText>&lt;html&gt;
  &lt;head style="color: #000000" color="#000000"&gt;
    &lt;style type="text/css"&gt;
      &lt;!--
        body { margin-top: 0px; color: #000000; font-family: Arial; margin-right: 0px; margin-left: 0px; margin-bottom: 0px; font-size: 12 }
        ol { list-style-position: outside; margin-top: 6; font-family: Arial; margin-left: 30; font-size: 12; vertical-align: middle }
        p { margin-top: 0; color: #000000; margin-right: 0; margin-left: 0; margin-bottom: 0 }
        ul { list-style-position: outside; margin-top: 6; font-family: Arial; margin-left: 30; font-size: 12; vertical-align: middle }
      --&gt;
    &lt;/style&gt;
    
  &lt;/head&gt;
  &lt;body&gt;
    &lt;p style="color: #000000" color="#000000"&gt;
      Debbie Walker | January 2015 | Goal 1: Assignment: Debug V3
    &lt;/p&gt;
  &lt;/body&gt;
&lt;/html&gt;
</richText>
        <label>Debbie Walker | January 2015 | Goal 1: Assignment: Debug V3</label>
    </child>
    <child ID="26" layerID="1" created="1421014333057" x="-180.04773"
        y="-292.6787" width="1.9156647" height="59.67871"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d00c0a800070093c5e7d92a2785</URIString>
        <point1 x="-178.63206" y="-292.1787"/>
        <point2 x="-179.54773" y="-233.5"/>
        <ID1 xsi:type="node">6</ID1>
        <ID2 xsi:type="node">7</ID2>
    </child>
    <child ID="42" label="query.carAt(query.length-1)===&quot; &quot;"
        layerID="1" created="1421015319833" x="-173.55475" y="121.35416"
        width="240.7" height="208.97937" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d07c0a800070093c5e71780d582</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="83" label="js" layerID="1" created="1421020330943"
        x="-431.0" y="-360.3331" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d11c0a800070093c5e71f8367cc</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="85" label="css" layerID="1" created="1421020361446"
        x="-429.5" y="-262.3331" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e76a1df893</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="86" label="images" layerID="1" created="1421020370053"
        x="-426.83334" y="-158.3331" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e7f64ddae6</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="90" label="HTML" layerID="1" created="1421020675678"
        x="-586.1171" y="-260.86462" width="69.0" height="76.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e77ff7bb8d</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="91" layerID="1" created="1421020701879" x="-530.00214"
        y="-322.26328" width="98.46838" height="61.89865"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d12c0a800070093c5e718c445bf</URIString>
        <point1 x="-529.50214" y="-260.86462"/>
        <point2 x="-432.03375" y="-321.76328"/>
        <ID1 xsi:type="node">90</ID1>
        <ctrlPoint0 x="-498.03088" y="-314.94128" xsi:type="point"/>
    </child>
    <child ID="92" layerID="1" created="1421020719826" x="-533.94324"
        y="-185.36462" width="107.60989" height="61.588486"
        strokeWidth="1.0" autoSized="false" controlCount="1"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d13c0a800070093c5e77c47c549</URIString>
        <point1 x="-533.44324" y="-184.86462"/>
        <point2 x="-426.83334" y="-124.27614"/>
        <ID1 xsi:type="node">90</ID1>
        <ID2 xsi:type="node">86</ID2>
        <ctrlPoint0 x="-508.95496" y="-133.66191" xsi:type="point"/>
    </child>
    <child ID="93" layerID="1" created="1421020746873" x="-517.6171"
        y="-224.50961" width="88.61713" height="1.821518"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d13c0a800070093c5e7fca13444</URIString>
        <point1 x="-517.1171" y="-223.1881"/>
        <point2 x="-429.5" y="-224.00961"/>
        <ID1 xsi:type="node">90</ID1>
        <ID2 xsi:type="node">85</ID2>
    </child>
    <child ID="95" label="user" layerID="1" created="1421020807438"
        x="-695.9333" y="-249.16081" width="79.2" height="53.650906"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/db743d14c0a800070093c5e7b2a00948</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="96" label="query=query.substring(1, query.length)"
        layerID="1" created="1421031269099" x="2.9321594" y="42.1669"
        width="222.0" height="81.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6aec0a800070093c5e791db14ae</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="97" label="query.charAt(0)===&quot; &quot;" layerID="1"
        created="1421031275555" x="-259.33322" y="14.667023"
        width="166.6" height="145.99976" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6aec0a800070093c5e721de0f2b</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="98" label="query.length &lt; 3" layerID="1"
        created="1421031281658" x="-28.333221" y="291.667"
        width="157.66669" height="145.99976" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6afc0a800070093c5e72270b8eb</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="101" label="CONNECT" layerID="1" created="1421031392619"
        x="-364.49988" y="121.33356" width="80.600006" height="84.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6afc0a800070093c5e79f2d6b6b</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="102" label="query = query.substring(0, query.ength - 1)"
        layerID="1" created="1421031812594" x="-634.33435" y="216.83356"
        width="242.0" height="81.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6afc0a800070093c5e79c6902b0</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="107" label="Define Global&#xa;Variables" layerID="1"
        created="1421031924143" x="192.51562" y="1097.8335"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6afc0a800070093c5e7781cf72e</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="108" label="Define Global&#xa;Variables" layerID="1"
        created="1421031928086" x="615.33185" y="1097.8335"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6afc0a800070093c5e79d62c1e1</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="109" label="results.length === 0" layerID="1"
        created="1421031934414" x="345.17288" y="881.8439"
        width="271.6897" height="208.97937" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6afc0a800070093c5e765cb9c82</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="110" label="search(query)" layerID="1"
        created="1421031972692" x="192.51562" y="323.16693"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e7df8954b9</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="111" label="for (var ii = 0, jj= query Array.length)"
        layerID="1" created="1421031980060" x="161.84908" y="465.83356"
        width="204.0" height="81.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e74f24dcb8</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="112" label="compare !== -1" layerID="1"
        created="1421031987132" x="185.25024" y="609.3337"
        width="157.66669" height="145.99976" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e74d8a4e5d</URIString>
        <shape xsi:type="diamond"/>
    </child>
    <child ID="113" label="results.push(db)" layerID="1"
        created="1421032025978" x="408.66537" y="641.83356"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e7ffb144ec</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="114" label="results.sort()" layerID="1"
        created="1421032068968" x="192.51562" y="805.83356"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e7c41ffd58</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="115" label="CONNECT" layerID="1" created="1421032418762"
        x="440.71774" y="1172.3335" width="80.600006" height="84.0"
        strokeWidth="1.0" autoSized="false" xsi:type="node">
        <fillColor>#FFC63B</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e77b334779</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="116" label="THE END" layerID="1" created="1421032431098"
        x="406.51773" y="1725.8335" width="149.0" height="49.0"
        strokeWidth="1.0" strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#DD7B11</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e73186775b</URIString>
        <shape xsi:type="ellipse"/>
    </child>
    <child ID="118" label="validate(query)" layerID="1"
        created="1421032441769" x="409.44977" y="1579.8335"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b0c0a800070093c5e7da8682fc</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="119" label=".indexOf('|')+1, results" layerID="1"
        created="1421032444682" x="409.44977" y="1313.8335"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b1c0a800070093c5e7889f06ff</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="120" label="onsubmit = function()" layerID="1"
        created="1421032453713" x="409.44977" y="1446.8335"
        width="143.13593" height="81.0" strokeWidth="1.0"
        strokeStyle="2" autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b1c0a800070093c5e7fd019544</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="121" layerID="1" created="1421032962768" x="-180.97148"
        y="-144.0" width="1.1143494" height="49.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b1c0a800070093c5e73833ddd0</URIString>
        <point1 x="-180.35713" y="-143.5"/>
        <point2 x="-180.47148" y="-95.5"/>
        <ID1 xsi:type="node">7</ID1>
        <ID2 xsi:type="node">13</ID2>
    </child>
    <child ID="122" layerID="1" created="1421032982847" x="-180.22662"
        y="-15.0" width="1.6266937" height="31.16687" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b1c0a800070093c5e7b0cc3bf1</URIString>
        <point1 x="-179.72662" y="-14.5"/>
        <point2 x="-179.09993" y="15.66687"/>
        <ID1 xsi:type="node">13</ID1>
    </child>
    <child ID="123" label="FALSE" layerID="1" created="1421033000502"
        x="-288.64267" y="114.04439" width="60.47931" height="31.375252"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b1c0a800070093c5e7fb4c9ff0</URIString>
        <point1 x="-228.66336" y="114.54438"/>
        <point2 x="-288.14267" y="144.91963"/>
        <ID1 xsi:type="node">97</ID1>
        <ID2 xsi:type="node">101</ID2>
    </child>
    <child ID="124" label="TRUE" layerID="1" created="1421033368779"
        x="-94.84063" y="78.919586" width="98.27279" height="13.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b1c0a800070093c5e75b73a24f</URIString>
        <point1 x="-94.34063" y="86.25824"/>
        <point2 x="2.9321594" y="84.580925"/>
        <ID1 xsi:type="node">97</ID1>
        <ID2 xsi:type="node">96</ID2>
    </child>
    <child ID="125" layerID="1" created="1421033416155" x="-285.3977"
        y="171.89937" width="137.60591" height="32.510803"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b1c0a800070093c5e7efaabe20</URIString>
        <point1 x="-284.8977" y="172.39937"/>
        <point2 x="-148.2918" y="203.91017"/>
        <ID1 xsi:type="node">101</ID1>
        <ID2 xsi:type="node">42</ID2>
    </child>
    <child ID="126" label="TRUE" layerID="1" created="1421033428850"
        x="-391.33325" y="218.99791" width="218.48766" height="13.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b2c0a800070093c5e70e4064b0</URIString>
        <point1 x="-173.3456" y="225.66226"/>
        <point2 x="-390.83325" y="225.33356"/>
        <ID1 xsi:type="node">42</ID1>
    </child>
    <child ID="127" layerID="1" created="1421033454080" x="-432.34558"
        y="180.85547" width="72.38431" height="36.478073"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b2c0a800070093c5e7ad3fea2a</URIString>
        <point1 x="-431.84558" y="216.83356"/>
        <point2 x="-360.46127" y="181.35548"/>
        <ID1 xsi:type="node">102</ID1>
        <ID2 xsi:type="node">101</ID2>
    </child>
    <child ID="128" label="FALSE" layerID="1" created="1421033783627"
        x="-10.795719" y="288.72537" width="34.0" height="33.291016"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b2c0a800070093c5e7fe4d45eb</URIString>
        <point1 x="-5.8568816" y="289.22537"/>
        <point2 x="18.265444" y="321.5164"/>
        <ID1 xsi:type="node">42</ID1>
        <ID2 xsi:type="node">98</ID2>
    </child>
    <child ID="129"
        label="(alert)&#xa;&quot;Your search query is too small, try again.&quot;"
        layerID="1" created="1421033833844" x="-337.4018" y="325.83356"
        width="239.0" height="81.0" strokeWidth="1.0" strokeStyle="2"
        autoSized="false" xsi:type="node">
        <fillColor>#F1A83E</fillColor>
        <strokeColor>#000000</strokeColor>
        <textColor>#000000</textColor>
        <font>Arial-plain-12</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b2c0a800070093c5e7cb63fef4</URIString>
        <shape xsi:type="rectangle"/>
    </child>
    <child ID="130" label="TRUE" layerID="1" created="1421033859486"
        x="-98.901794" y="358.8723" width="71.59371" height="13.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b2c0a800070093c5e77b1eecb8</URIString>
        <point1 x="-27.808083" y="365.15314"/>
        <point2 x="-98.401794" y="365.59152"/>
        <ID1 xsi:type="node">98</ID1>
        <ID2 xsi:type="node">129</ID2>
    </child>
    <child ID="131" label="FALSE" layerID="1" created="1421033894367"
        x="128.43689" y="357.65082" width="64.57872" height="13.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b2c0a800070093c5e70e2c64c3</URIString>
        <point1 x="128.9369" y="364.29965"/>
        <point2 x="192.51562" y="364.00198"/>
        <ID1 xsi:type="node">98</ID1>
        <ID2 xsi:type="node">110</ID2>
    </child>
    <child ID="132" layerID="1" created="1421034060448" x="263.41565"
        y="403.67188" width="1.1013489" height="62.65625"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b2c0a800070093c5e74ab4df36</URIString>
        <point1 x="264.017" y="404.17188"/>
        <point2 x="263.91565" y="465.82812"/>
        <ID1 xsi:type="node">110</ID1>
        <ID2 xsi:type="node">111</ID2>
    </child>
    <child ID="133" layerID="1" created="1421034124549" x="263.403"
        y="546.3281" width="1.0834045" height="63.578125"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b3c0a800070093c5e7f1874f4a</URIString>
        <point1 x="263.903" y="546.8281"/>
        <point2 x="263.98642" y="609.40625"/>
        <ID1 xsi:type="node">111</ID1>
        <ID2 xsi:type="node">112</ID2>
    </child>
    <child ID="134" label="TRUE" layerID="1" created="1421034144978"
        x="342.41693" y="675.83356" width="66.74844" height="13.0"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b4c0a800070093c5e735c6bed3</URIString>
        <point1 x="342.91693" y="682.33356"/>
        <point2 x="408.66537" y="682.33356"/>
        <ID1 xsi:type="node">112</ID1>
        <ID2 xsi:type="node">113</ID2>
    </child>
    <child ID="135" label="FALSE" layerID="1" created="1421034158907"
        x="247.08359" y="754.8334" width="34.0" height="51.500183"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b4c0a800070093c5e72d779c2f</URIString>
        <point1 x="264.0836" y="755.3334"/>
        <point2 x="264.0836" y="805.83356"/>
        <ID1 xsi:type="node">112</ID1>
        <ID2 xsi:type="node">114</ID2>
    </child>
    <child ID="136" layerID="1" created="1421034338401" x="326.33954"
        y="886.3335" width="81.309906" height="52.828552"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b4c0a800070093c5e71174581e</URIString>
        <point1 x="326.83954" y="886.83356"/>
        <point2 x="407.14944" y="938.6621"/>
        <ID1 xsi:type="node">114</ID1>
        <ID2 xsi:type="node">109</ID2>
    </child>
    <child ID="137" label="FALSE" layerID="1" created="1421034348048"
        x="321.38528" y="1035.6433" width="89.04419" height="62.690186"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b4c0a800070093c5e7c31a9066</URIString>
        <point1 x="409.92947" y="1036.1433"/>
        <point2 x="321.88528" y="1097.8335"/>
        <ID1 xsi:type="node">109</ID1>
        <ID2 xsi:type="node">107</ID2>
    </child>
    <child ID="138" label="TRUE" layerID="1" created="1421034369395"
        x="549.83234" y="1037.0076" width="82.71069" height="61.325928"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b4c0a800070093c5e7068191d3</URIString>
        <point1 x="550.33234" y="1037.5076"/>
        <point2 x="632.043" y="1097.8335"/>
        <ID1 xsi:type="node">109</ID1>
        <ID2 xsi:type="node">108</ID2>
    </child>
    <child ID="139" layerID="1" created="1421034378535" x="335.15155"
        y="1162.9064" width="108.33252" height="38.60254"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b5c0a800070093c5e75017d783</URIString>
        <point1 x="335.65155" y="1163.4064"/>
        <point2 x="442.98407" y="1201.0089"/>
        <ID1 xsi:type="node">107</ID1>
        <ID2 xsi:type="node">115</ID2>
    </child>
    <child ID="140" layerID="1" created="1421034382124" x="518.35944"
        y="1164.2522" width="97.47241" height="36.612183"
        strokeWidth="1.0" autoSized="false" controlCount="0"
        arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b5c0a800070093c5e7677d0db0</URIString>
        <point1 x="615.33185" y="1164.7523"/>
        <point2 x="518.85944" y="1200.3645"/>
        <ID1 xsi:type="node">108</ID1>
        <ID2 xsi:type="node">115</ID2>
    </child>
    <child ID="141" layerID="1" created="1421034397096" x="480.51776"
        y="1255.8335" width="1.0" height="58.5" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b5c0a800070093c5e7c34fc3b4</URIString>
        <point1 x="481.01776" y="1256.3335"/>
        <point2 x="481.01776" y="1313.8335"/>
        <ID1 xsi:type="node">115</ID1>
        <ID2 xsi:type="node">119</ID2>
    </child>
    <child ID="142" layerID="1" created="1421034459966" x="480.51773"
        y="1394.3335" width="1.0" height="53.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b5c0a800070093c5e7d7eb28f8</URIString>
        <point1 x="481.01773" y="1394.8335"/>
        <point2 x="481.01773" y="1446.8335"/>
        <ID1 xsi:type="node">119</ID1>
        <ID2 xsi:type="node">120</ID2>
    </child>
    <child ID="143" layerID="1" created="1421034466712" x="480.51773"
        y="1527.3335" width="1.0" height="53.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b5c0a800070093c5e787ab4a88</URIString>
        <point1 x="481.01773" y="1527.8335"/>
        <point2 x="481.01773" y="1579.8335"/>
        <ID1 xsi:type="node">120</ID1>
        <ID2 xsi:type="node">118</ID2>
    </child>
    <child ID="144" layerID="1" created="1421034472584" x="480.51773"
        y="1660.3335" width="1.0" height="66.0" strokeWidth="1.0"
        autoSized="false" controlCount="0" arrowState="2" xsi:type="link">
        <strokeColor>#404040</strokeColor>
        <textColor>#404040</textColor>
        <font>Arial-plain-11</font>
        <URIString>http://vue.tufts.edu/rdf/resource/dc44d6b5c0a800070093c5e7c294e599</URIString>
        <point1 x="481.01773" y="1660.8335"/>
        <point2 x="481.01773" y="1725.8335"/>
        <ID1 xsi:type="node">118</ID1>
        <ID2 xsi:type="node">116</ID2>
    </child>
    <layer ID="1" label="Layer 1" created="1421011985533" x="0.0"
        y="0.0" width="1.4E-45" height="1.4E-45" strokeWidth="0.0" autoSized="false">
        <URIString>http://vue.tufts.edu/rdf/resource/db743d14c0a800070093c5e71a7e0ef3</URIString>
    </layer>
    <userZoom>0.3343877089923181</userZoom>
    <userOrigin x="-886.3705" y="-565.69617"/>
    <presentationBackground>#202020</presentationBackground>
    <PathwayList currentPathway="0" revealerIndex="-1">
        <pathway ID="0" label="Untitled Pathway" created="1421011985533"
            x="0.0" y="0.0" width="1.4E-45" height="1.4E-45"
            strokeWidth="0.0" autoSized="false" currentIndex="0" open="true">
            <strokeColor>#B3CC33CC</strokeColor>
            <textColor>#000000</textColor>
            <font>SansSerif-plain-14</font>
            <URIString>http://vue.tufts.edu/rdf/resource/db743d14c0a800070093c5e7a58ac94e</URIString>
            <masterSlide ID="2" created="1421011985644" x="0.0" y="0.0"
                width="800.0" height="600.0" locked="true"
                strokeWidth="0.0" autoSized="false">
                <fillColor>#000000</fillColor>
                <strokeColor>#404040</strokeColor>
                <textColor>#000000</textColor>
                <font>SansSerif-plain-14</font>
                <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e7c9c38b08</URIString>
                <titleStyle ID="3" label="Header"
                    created="1421011985651" x="341.0" y="175.0"
                    width="118.0" height="50.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-36</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e79b62f077</URIString>
                    <shape xsi:type="rectangle"/>
                </titleStyle>
                <textStyle ID="4" label="Slide Text"
                    created="1421011985651" x="349.5" y="282.5"
                    width="101.0" height="35.0" strokeWidth="0.0"
                    autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#FFFFFF</textColor>
                    <font>Gill Sans-plain-22</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e78058b35e</URIString>
                    <shape xsi:type="rectangle"/>
                </textStyle>
                <linkStyle ID="5" label="Links" created="1421011985652"
                    x="375.5" y="385.0" width="49.0" height="30.0"
                    strokeWidth="0.0" autoSized="true" isStyle="true" xsi:type="node">
                    <strokeColor>#404040</strokeColor>
                    <textColor>#B3BFE3</textColor>
                    <font>Gill Sans-plain-18</font>
                    <URIString>http://vue.tufts.edu/rdf/resource/db743d15c0a800070093c5e70b272010</URIString>
                    <shape xsi:type="rectangle"/>
                </linkStyle>
            </masterSlide>
        </pathway>
    </PathwayList>
    <date>2015-01-11</date>
    <modelVersion>6</modelVersion>
    <saveLocation>/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/PWA1_WorkingDocs/Day9</saveLocation>
    <saveFile>/Users/debbiewalker/RootFull/Debbie-Walker-PWA1/PWA1_WorkingDocs/Day9/Day3BugFlowchart_Walker_Debbie-copy.vue</saveFile>
</LW-MAP>
